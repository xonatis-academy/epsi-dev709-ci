package academy.certif.hrlister;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HrlisterApplication {

	public static void main(String[] args) {
		SpringApplication.run(HrlisterApplication.class, args);
	}

}
